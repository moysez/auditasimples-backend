# AuditaSimples API (Render)
Verifique /health. Use /api/login para obter o token JWT.
